package qwq.wumie.module.impl.games.impl;

import qwq.wumie.Launch;
import qwq.wumie.events.EventHandler;
import qwq.wumie.events.message.MessageEvent;
import qwq.wumie.module.impl.games.GameMode;
import qwq.wumie.module.impl.register.Register;
import qwq.wumie.module.impl.register.User;
import qwq.wumie.module.results.AtResult;
import qwq.wumie.utils.RandomUtils;

public class Pyramid extends GameMode {
    private int counts = 5;
    private boolean can = false;
    private boolean first = false;
    private boolean idk = true;
    private double money = 20;
    private int boomPosition = RandomUtils.nextInt(1,counts);

    public Pyramid() {
        super("������", 1);
    }

    @Override
    public void onJoin(String qq) {
        AtResult result = new AtResult(qq);
        if (started) {
            info(result.toJSON() + "��Ϸ��ʼ��");
            return;
        }
        if (players.size() < maxPlayer) {
            if (getUser(qq) == null) {
                players.add(Register.get(qq));
            } else {
                info(result.toJSON() + "���Ѿ�������");
            }
            super.onJoin(qq);
        } else {
            info(result.toJSON() + "��Ϸ�Ѿ���ʼ�������㹻��");
        }
    }

    @EventHandler
    private void onMessage(MessageEvent e) {
        String message = e.message.getRaw_message();
        String qq = e.message.getUser_id();
        loop(qq,message,e.message.getGroup_id());
    }

    public void loop(String qq,String message,String group) {
        if (qq.equalsIgnoreCase(players.get(0).getUser_id())) {
            if (counts >= 128) {
                info(group,"��Ϸ����,������"+this.money+"��");
                User user = Register.get(qq,false);
                user.setBal((int) (user.getBal()+this.money));
                Register.save();
                end();
                return;
            }

            if (first) {
                if (message.startsWith("Ͷ��")) {
                    int money = Integer.parseInt(message.substring("Ͷ��".length()));
                    if (!(money < 20)) {
                        this.money = money;

                    }
                    info(group,"����Ͷ��" + money + "��");
                }
                first = false;
                loop(qq,"",group);
                return;
            }
            if (can) {
                if (message.startsWith("����")) {
                    int num = Integer.parseInt(message.substring("����".length()));
                    if (num < 1 || num > counts) {
                        info(Integer.parseInt(group),"���ִ���" + counts + "��С��һ��ǰ��ʧ��:(", "����������","");
                        return;
                    }
                    if (num == boomPosition) {
                        info(Integer.parseInt(group),"��ʲôҲû�ȵ���������һ��");
                    } else {
                        double money = this.money*(RandomUtils.nextDouble(counts-counts*10,counts) * (0.1*(RandomUtils.nextInt(counts-counts/2,counts) * 0.1)));
                        double offset = (int) (money - this.money);
                        String tip = (offset < 0) ? "����" : "����";
                        if (idk) {
                            info(Integer.parseInt(group),"���������ը�������Ǯ������"+tip);
                            idk = false;
                            counts++;
                            can = false;
                            loop(qq, "",group);
                            return;
                        }
                        this.money = money;
                        info(Integer.parseInt(group),"��ȵ���ը��", "��ģ���"+tip+offset,"��ǰ����"+this.money,"��ǰ����"+counts);
                    }
                    counts++;
                    can = false;
                    loop(qq,"",group);
                }
            } else {
                info("��ǰ����" + counts, "���롰����<1-" + counts + ">��ǰ��");
                can = true;
            }
                int boomPosition = RandomUtils.nextInt(1, counts);
            if (can) {
                Launch.info("ͨ��:" + boomPosition);
            }
        }
    }

    @Override
    public void start() {
        started = true;
        info("���룤����20��С��������,�÷���Ͷ��<����>��");
        first = true;
        super.start();
    }

    @Override
    public void end() {
        super.end();
    }
}
